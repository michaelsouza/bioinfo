function x = intersect3spheres(a,da,b,db,c,dc)
n = cross(a-c,b-c);
n = n / norm(n);

A = [a-c;
     b-c;
     n];

y = [(a*a' - c*c' - da^2 + dc^2)/2;
    (b*b' - c*c' - db^2 + dc^2)/2;
    n*a'];

p = (A \ y)';

dpa = norm(p-a);
dp  = sqrt(da^2-dpa^2);
x   = [p + dp * n;
       p - dp * n];
end