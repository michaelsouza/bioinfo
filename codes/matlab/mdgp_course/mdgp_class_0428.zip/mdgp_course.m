%% Class 1.A: Creating an instance from a known solution ==================
x = rand(5,3);
problem = create_mdgp_instance(x);
plot_dgp_problem(problem);

%% Class 1.B: Creating a random instance ==================================
problem = create_mdgp_instance_rand(10);
plot_dgp_problem(problem);

%% Class 1.C: Calculating the protein angles ==============================
x = [0 0 0;
     1 0 0;
     1 1 0;
     1 1 1];
problem = create_mdgp_instance(x);
plot_dgp_problem(problem);
view_molecule(problem.x);
calc_protein_angles(problem.x);

%% Class 1.C: Checking the quality of a MDGP solution =====================
problem  = create_mdgp_instance_rand(10);
check_dgp_solution(problem, problem. x);

x = problem.x + 0.01 * rand(problem.natoms, 3);
check_dgp_solution(problem, x);

%% Class 1.D: Visualizing a protein (solution) ============================
problem = create_mdgp_instance_rand(10);
% plot_molecule(problem.x);
view_molecule(problem.x);

%% Class 1.E: Solving a DGP instance using nonlinear equations ============
problem = create_mdgp_instance_rand(30);
x = solver_sys(problem);
check_dgp_solution(problem, x);

%% Class 2.A: Creating and solnving a small problem =======================
x = [0 0 0;
    1 0 0;
    1 1 0;
    1 1 -1;
    1 0 -1];
% i = [1 2 3 4, 1, 2, 3, 1];
% j = [2 3 4 5, 3, 4, 5, 5];
problem = create_mdgp_instance(x);
plot_dgp_problem(problem);
y = solver_sys(problem);
check_dgp_solution(problem, y);

%% Class 2.B: RMSD - Check if the solution is different ===================
% plot y and x
figure
view_molecule(x);
hold on
view_molecule(y);

% check if x and y represent the same structure
[rmsd,x_new,y_new] = calc_rmsd(x,y);
fprintf('rmsd(x,y) = %3.2e\n', rmsd);

% plot y and x
figure
view_molecule(x_new);
hold on
view_molecule(y_new);
%% Class 3.A: Solving the optimization formulation of DGP =================
problem = create_mdgp_instance_rand(20);
tic
[x,f] = solver_opt(problem);
fprintf('Elapsed time %3.2f seconds\n', toc);
check_dgp_solution(problem, x);

%% Class 3.B: Solving a DGP instance with all constraints =================
problem = create_mdgp_instance_rand(100, inf);
tic
x = solver_eig(problem);
fprintf('Elapsed time %3.2f seconds\n', toc);
check_dgp_solution(problem, x);

%% Class 3.C: Solving a system with three quadratic equations =============
a = rand(1,3);
b = rand(1,3);
c = rand(1,3);
x = rand(1,3);
da = norm(a - x);
db = norm(b - x);
dc = norm(c - x);
y = intersect3spheres(a,da,b,db,c,dc);


%% Class 3.D: Solving a system with four quadratic equations ==============
a = rand(1,3);
b = rand(1,3);
c = rand(1,3);
d = rand(1,3);
x = rand(1,3);
da = norm(a - x);
db = norm(b - x);
dc = norm(c - x);
dd = norm(d - x);
y = intersect4spheres(a,da,b,db,c,dc,d,dd);
