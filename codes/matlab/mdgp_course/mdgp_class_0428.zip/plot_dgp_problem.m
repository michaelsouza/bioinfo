function plot_dgp_problem(problem)
fprintf('natoms: %d\n', problem.natoms);
fprintf('nedges: %d\n', problem.nedges);
fprintf('id\t i\t j\t  d\t\t  l\t\t  u\n');
fprintf('%c%c%c %c%c%c %c%c%c %c%c%c%c%c\t%c%c%c%c%c\t%c%c%c%c%c\n',175 * ones(24,1))
for k = 1:problem.nedges
    fprintf('%3d\t%3d\t%3d\t%4.3f\t%4.3f\t%4.3f\n', ...
    k, problem.i(k), problem.j(k), problem.d(k), ...
    problem.l(k),problem.u(k));
end
end